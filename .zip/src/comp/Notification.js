

function Notification() {
    return ( 
        <section className="noti">
           
 <div class="announcement-item">
    <div class="announcement_bar">
      <marquee>
      <div className="me-auto ms-5">
      <p >The UK's leading personalised clothing company</p>

      </div>
      </marquee>
      <marquee>
      <div className="ms-auto me-4">
      <p className="">Corporate users | contact us: +44 7973 883660</p>
      </div>
      </marquee>
      
 </div>
   
  </div>
        </section>
     );
}

export default Notification;