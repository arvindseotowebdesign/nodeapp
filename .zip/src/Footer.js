

function Footer() {
    return (
        <section>
            <div className="footer3">
                 <div className="row px-0 mx-0" id="frow">
                    <div className="col-md-12 " id="crt">
                    <h5 className="mt-2">Copyright © 2023, Brand Me Now. </h5>
                    </div>
                </div>
            </div>

        </section>
    );
}

export default Footer;